#!/usr/bin/bash

sudo rmmod mydev
sudo rm /dev/mydev
